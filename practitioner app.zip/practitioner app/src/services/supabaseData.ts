import { supabase } from './supabase';

export type PractitionerProfile = {
  id: string;
  auth_id: string | null;
  role: 'learner' | 'practitioner' | 'admin';
  name: string;
  email: string;
  phone: string | null;
  province: string | null;
  town: string | null;
  hub_id: string | null;
  certification: string | null;
  organization: string | null;
  status: string;
  verification_status: string;
};

export type SessionRegister = {
  id: string;
  hub_id: string;
  practitioner_id: string;
  session_date: string;
  notes: string | null;
  created_at: string;
  attendees: { learner_id: string; present: boolean }[];
};

export type CheckInLog = {
  id: string;
  learner_id: string;
  practitioner_id: string;
  occurred_on: string;
  reasons: string[];
  notes: string;
  resolved: boolean;
  resolved_at: string | null;
};

export type PostedAssessment = {
  id: string;
  title: string;
  description: string;
  kind: 'diagnostic' | 'quiz' | 'practical';
  competency_area: string | null;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  questions: unknown[];
  hub_id: string;
  creator_name: string;
  is_published: boolean;
  due_at: string | null;
  max_attempts: number;
};

export type ModuleAssignment = {
  id: string;
  course_id: string;
  module_id: string;
  title: string;
  instructions: string;
  due_at: string | null;
  submissions: AssignmentSubmission[];
};

export type AssignmentSubmission = {
  id: string;
  assignment_id: string;
  learner_id: string;
  response: string;
  submitted_at: string;
  status: 'submitted' | 'reviewed';
  feedback: string | null;
};

export type HubRow = {
  id: string;
  name: string;
  province: string;
  town: string | null;
  contact_name: string | null;
  contact_email: string | null;
  is_active: boolean;
};

/** Email + password sign-in for practitioners (Supabase Auth). */
export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: email.trim().toLowerCase(),
    password,
  });
  if (error) throw new Error(error.message);
  return data;
}

export async function signUp(email: string, password: string, name: string) {
  const { data, error } = await supabase.auth.signUp({
    email: email.trim().toLowerCase(),
    password,
    options: { data: { full_name: name, role: 'practitioner' } },
  });
  if (error) throw new Error(error.message);
  if (data.user) {
    // Mirror into public.users so FKs (session_registers, posted_assessments…) resolve.
    await supabase.from('users').upsert(
      {
        auth_id: data.user.id,
        role: 'practitioner',
        name,
        email: email.trim().toLowerCase(),
        status: 'active',
        verification_status: 'pending',
      },
      { onConflict: 'auth_id' },
    );
  }
  return data;
}

export async function signOut() {
  await supabase.auth.signOut();
}

export async function getSessionUserId() {
  const { data } = await supabase.auth.getSession();
  return data.session?.user?.id ?? null;
}

/** Load the practitioner's row from public.users by their auth uid or email. */
export async function fetchProfile(authId: string, email: string): Promise<PractitionerProfile | null> {
  let { data } = await supabase
    .from('users')
    .select('*')
    .eq('auth_id', authId)
    .maybeSingle();
  if (!data) {
    ({ data } = await supabase.from('users').select('*').eq('email', email.toLowerCase()).maybeSingle());
    if (data) {
      // Link orphan profile row to this auth user.
      await supabase.from('users').update({ auth_id: authId }).eq('id', data.id);
    }
  }
  return (data as PractitionerProfile) ?? null;
}

/** Hubs list (for the hub picker / sessions). */
export async function fetchHubs(): Promise<HubRow[]> {
  const { data, error } = await supabase
    .from('hubs')
    .select('id,name,province,town,contact_name,contact_email,is_active')
    .eq('is_active', true)
    .order('name');
  if (error) throw new Error(error.message);
  return (data ?? []) as HubRow[];
}

/** Sessions registered by a practitioner, with attendees. */
export async function fetchSessions(practitionerId: string): Promise<SessionRegister[]> {
  const { data, error } = await supabase
    .from('session_registers')
    .select('*')
    .eq('practitioner_id', practitionerId)
    .order('session_date', { ascending: false });
  if (error) throw new Error(error.message);
  const rows = (data ?? []) as Omit<SessionRegister, 'attendees'>[];
  const ids = rows.map((r) => r.id);
  let attendees: { session_id: string; learner_id: string; present: boolean }[] = [];
  if (ids.length) {
    const res = await supabase.from('session_attendees').select('session_id,learner_id,present').in('session_id', ids);
    attendees = (res.data ?? []) as typeof attendees;
  }
  return rows.map((r) => ({
    ...r,
    attendees: attendees.filter((a) => a.session_id === r.id).map((a) => ({ learner_id: a.learner_id, present: a.present })),
  }));
}

export async function registerSession(input: {
  hub_id: string;
  practitioner_id: string;
  session_date: string;
  notes?: string;
  attendees: { learner_id: string; present: boolean }[];
}): Promise<SessionRegister> {
  const { attendeeIds } = (() => ({ attendeeIds: input.attendees.map((a) => a.learner_id) }))();
  const { data, error } = await supabase
    .from('session_registers')
    .insert({
      hub_id: input.hub_id,
      practitioner_id: input.practitioner_id,
      session_date: input.session_date,
      notes: input.notes ?? null,
    })
    .select()
    .single();
  if (error) throw new Error(error.message);
  const session = data as Omit<SessionRegister, 'attendees'>;
  if (attendeeIds.length) {
    await supabase
      .from('session_attendees')
      .upsert(attendeeIds.map((lid) => ({ session_id: session.id, learner_id: lid, present: true })));
  }
  return { ...session, attendees: input.attendees };
}

/** Check-in logs for a practitioner. */
export async function fetchCheckIns(practitionerId: string): Promise<CheckInLog[]> {
  const { data, error } = await supabase
    .from('check_in_logs')
    .select('*')
    .eq('practitioner_id', practitionerId)
    .order('occurred_on', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as CheckInLog[];
}

export async function logCheckIn(input: {
  learner_id: string;
  practitioner_id: string;
  reasons: string[];
  notes: string;
}) {
  const { data, error } = await supabase
    .from('check_in_logs')
    .insert({
      learner_id: input.learner_id,
      practitioner_id: input.practitioner_id,
      reasons: input.reasons,
      notes: input.notes,
    })
    .select()
    .single();
  if (error) throw new Error(error.message);
  return data as CheckInLog;
}

export async function resolveCheckIn(id: string) {
  const { error } = await supabase
    .from('check_in_logs')
    .update({ resolved: true, resolved_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw new Error(error.message);
}

/** Posted assessments created by / visible to the practitioner's hub. */
export async function fetchAssessments(hubId: string): Promise<PostedAssessment[]> {
  const { data, error } = await supabase
    .from('posted_assessments')
    .select('*')
    .eq('hub_id', hubId)
    .eq('is_published', true)
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as PostedAssessment[];
}

export async function createAssessment(input: Omit<PostedAssessment, 'creator_name' | 'is_published'> & { creator_name: string }) {
  const { data, error } = await supabase.from('posted_assessments').insert(input).select().single();
  if (error) throw new Error(error.message);
  return data as PostedAssessment;
}

/** Assignments for modules, with submissions. */
export async function fetchAssignments(createdBy: string): Promise<ModuleAssignment[]> {
  const { data, error } = await supabase
    .from('module_assignments')
    .select('*')
    .eq('created_by', createdBy)
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  const rows = (data ?? []) as Omit<ModuleAssignment, 'submissions'>[];
  const ids = rows.map((r) => r.id);
  let subs: AssignmentSubmission[] = [];
  if (ids.length) {
    const res = await supabase.from('assignment_submissions').select('*').in('assignment_id', ids);
    subs = (res.data ?? []) as AssignmentSubmission[];
  }
  return rows.map((r) => ({ ...r, submissions: subs.filter((s) => s.assignment_id === r.id) }));
}

export async function createAssignment(input: {
  course_id: string;
  module_id: string;
  title: string;
  instructions: string;
  due_at?: string | null;
  created_by: string;
}) {
  const { data, error } = await supabase
    .from('module_assignments')
    .insert({ ...input, due_at: input.due_at ?? null })
    .select()
    .single();
  if (error) throw new Error(error.message);
  return { ...(data as Omit<ModuleAssignment, 'submissions'>), submissions: [] } as ModuleAssignment;
}

export async function reviewSubmission(submissionId: string, feedback: string) {
  const { error } = await supabase
    .from('assignment_submissions')
    .update({ status: 'reviewed', feedback })
    .eq('id', submissionId);
  if (error) throw new Error(error.message);
}

/** Learners attached to a hub (for attendance pickers). */
export async function fetchHubLearners(hubId: string): Promise<{ id: string; name: string; email: string; current_level: string }[]> {
  const { data, error } = await supabase
    .from('users')
    .select('id,name,email,current_level')
    .eq('role', 'learner')
    .eq('hub_id', hubId)
    .eq('status', 'active')
    .order('name');
  if (error) throw new Error(error.message);
  return (data ?? []) as any;
}
